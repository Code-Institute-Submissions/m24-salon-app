This is an app designed to bring an easy to use streamlined admin system for 
small salons it includes registration, bookings, expenditure, real time financial 
graphic overview.


Base.html points to the USER/CLIENT index page